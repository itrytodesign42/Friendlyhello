(() => {
  const $ = id => document.getElementById(id);
  const intro = $("intro"), app = $("app");
  const ageCheck = $("ageCheck"), rulesCheck = $("rulesCheck");
  const continueBtn = $("continueBtn"), cameraBtn = $("cameraBtn");
  const startBtn = $("startBtn"), nextBtn = $("nextBtn"), leaveBtn = $("leaveBtn");
  const reportBtn = $("reportBtn"), localVideo = $("localVideo"), remoteVideo = $("remoteVideo");
  const localPlaceholder = $("localPlaceholder"), remotePlaceholder = $("remotePlaceholder");
  const statusEl = $("status"), remoteHint = $("remoteHint"), toastEl = $("toast");
  let localStream = null, socket = null, pc = null, partnerId = null, adTimer = null, adPassed = false;
  let connected = false, waiting = false;

  function toast(message) {
    toastEl.textContent = message;
    toastEl.classList.remove("hidden");
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => toastEl.classList.add("hidden"), 3200);
  }
  function updateGate() { continueBtn.disabled = !(ageCheck.checked && rulesCheck.checked); }
  ageCheck.addEventListener("change", updateGate);
  rulesCheck.addEventListener("change", updateGate);

  continueBtn.addEventListener("click", () => {
    if (!ageCheck.checked || !rulesCheck.checked) return;
    intro.classList.add("hidden"); app.classList.remove("hidden");
    statusEl.textContent = "Turn on your camera to begin";
  });

  async function turnCameraOn() {
    if (localStream) return true;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      toast("Camera access requires HTTPS. Open the deployed secure website and try again.");
      return false;
    }
    try {
      localStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" }, audio: true });
      localVideo.srcObject = localStream;
      localPlaceholder.classList.add("hidden");
      cameraBtn.textContent = "Camera on ✓";
      startBtn.disabled = false;
      statusEl.textContent = "Camera ready";
      return true;
    } catch (e) {
      toast("Camera and microphone permission are needed for video chat.");
      return false;
    }
  }
  cameraBtn.addEventListener("click", turnCameraOn);

  function resetPeer() {
    if (pc) { try { pc.onicecandidate = null; pc.close(); } catch(e) {} }
    pc = null; partnerId = null; connected = false;
    remoteVideo.srcObject = null;
    remotePlaceholder.classList.remove("hidden");
    remoteHint.textContent = "Your next friendly hello is waiting.";
    reportBtn.disabled = true;
  }
  function stopAd() { clearInterval(adTimer); adTimer = null; $("adbox").classList.remove("hidden"); }
  function playIntroAd() {
    adPassed = false;
    startBtn.disabled = true;
    startBtn.textContent = "Please wait…";
    let seconds = 5;
    $("adTimer").textContent = seconds;
    $("adbox").classList.remove("hidden");
    adTimer = setInterval(() => {
      seconds--;
      $("adTimer").textContent = seconds;
      if (seconds <= 0) {
        stopAd(); adPassed = true;
        startBtn.textContent = "Find a friendly chat";
        startBtn.disabled = false;
      }
    }, 1000);
  }
  startBtn.addEventListener("click", async () => {
    if (!await turnCameraOn()) return;
    if (!adPassed) { playIntroAd(); return; }
    if (!socket) {
      socket = io({ transports: ["websocket", "polling"] });
      socket.on("connect", () => {
        statusEl.textContent = "Finding a person…";
        socket.emit("find-partner");
      });
      socket.on("waiting", () => {
        waiting = true; statusEl.textContent = "Finding a person…";
        remoteHint.textContent = "Waiting for another adult to join. You can leave anytime.";
        startBtn.classList.add("hidden"); nextBtn.classList.remove("hidden"); leaveBtn.classList.remove("hidden");
      });
      socket.on("matched", async ({ initiator, partnerId: id }) => {
        waiting = false; partnerId = id;
        statusEl.textContent = "Connecting securely…";
        await setupPeer(initiator);
      });
      socket.on("signal", async ({ data }) => {
        if (!pc) return;
        try {
          if (data.sdp) {
            await pc.setRemoteDescription(data.sdp);
            if (data.sdp.type === "offer") {
              const answer = await pc.createAnswer();
              await pc.setLocalDescription(answer);
              socket.emit("signal", { to: partnerId, data: { sdp: pc.localDescription } });
            }
          } else if (data.candidate) await pc.addIceCandidate(data.candidate);
        } catch (e) { console.error("Signaling error", e); }
      });
      socket.on("partner-left", () => {
        resetPeer(); statusEl.textContent = "The other person left";
        remoteHint.textContent = "They've left the chat. You can find someone else.";
        startBtn.classList.remove("hidden"); startBtn.textContent = "Find another person";
        startBtn.disabled = false; adPassed = true;
      });
      socket.on("report-received", () => toast("Report received. Thank you for helping keep the community respectful."));
      socket.on("connect_error", () => toast("Connection issue. Please try again in a moment."));
    } else {
      statusEl.textContent = "Finding a person…";
      socket.emit("find-partner");
    }
    startBtn.classList.add("hidden"); nextBtn.classList.remove("hidden"); leaveBtn.classList.remove("hidden");
  });

  async function setupPeer(initiator) {
    // Preserve the newly matched partner ID while replacing any stale peer connection.
    if (pc) { try { pc.onicecandidate = null; pc.close(); } catch(e) {} }
    pc = null;
    connected = false;
    remoteVideo.srcObject = null;
    remotePlaceholder.classList.remove("hidden");
    reportBtn.disabled = true;
    // Public STUN helps many connections; production needs a TURN relay for reliability.
    pc = new RTCPeerConnection({ iceServers: [{ urls: "stun:stun.l.google.com:19302" }] });
    localStream.getTracks().forEach(track => pc.addTrack(track, localStream));
    pc.ontrack = e => {
      remoteVideo.srcObject = e.streams[0];
      remotePlaceholder.classList.add("hidden");
      connected = true; statusEl.textContent = "You're connected";
      reportBtn.disabled = false;
    };
    pc.onicecandidate = e => {
      if (e.candidate && partnerId) socket.emit("signal", { to: partnerId, data: { candidate: e.candidate } });
    };
    pc.onconnectionstatechange = () => {
      if (["failed", "disconnected", "closed"].includes(pc.connectionState)) {
        statusEl.textContent = "Connection interrupted";
      }
    };
    if (initiator) {
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      socket.emit("signal", { to: partnerId, data: { sdp: pc.localDescription } });
    }
  }

  nextBtn.addEventListener("click", () => {
    resetPeer();
    if (socket) socket.emit("next");
    statusEl.textContent = "Finding a person…";
    remoteHint.textContent = "Looking for another adult.";
  });
  leaveBtn.addEventListener("click", () => {
    if (socket) socket.emit("leave");
    resetPeer(); stopAd();
    startBtn.classList.remove("hidden"); startBtn.textContent = "Watch intro ad to connect"; startBtn.disabled = false; adPassed = false;
    nextBtn.classList.add("hidden"); leaveBtn.classList.add("hidden");
    statusEl.textContent = "You've left the chat";
    remoteHint.textContent = "Your next friendly hello is waiting.";
  });
  reportBtn.addEventListener("click", () => {
    if (!socket || !partnerId) return;
    const category = prompt("What are you reporting? Enter: inappropriate behavior, harassment, suspected minor, nudity, or other.");
    if (!category) return;
    socket.emit("report", { category });
    resetPeer();
    statusEl.textContent = "Report submitted";
    startBtn.classList.remove("hidden"); startBtn.textContent = "Find another person"; startBtn.disabled = false; adPassed = true;
    nextBtn.classList.add("hidden"); leaveBtn.classList.add("hidden");
  });

  window.addEventListener("beforeunload", () => {
    if (socket) socket.emit("leave");
    if (localStream) localStream.getTracks().forEach(t => t.stop());
    resetPeer();
  });
})();