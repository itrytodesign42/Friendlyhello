const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: false },
  maxHttpBufferSize: 1e6
});

const PORT = process.env.PORT || 3000;
app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true }));

// Lightweight MVP queue. Production deployment needs moderation, rate limiting,
// TURN servers, abuse monitoring, and stronger age/safety controls.
const waiting = [];
const peers = new Map(); // socket id -> partner id
const reports = [];

function removeFromQueue(id) {
  const i = waiting.indexOf(id);
  if (i !== -1) waiting.splice(i, 1);
}

function disconnectPair(id, reason = "partner-left") {
  const partnerId = peers.get(id);
  peers.delete(id);
  if (partnerId) {
    peers.delete(partnerId);
    const partner = io.sockets.sockets.get(partnerId);
    if (partner) partner.emit("partner-left", { reason });
  }
}

function findPartner(socket) {
  removeFromQueue(socket.id);
  // Don't pair with a socket that has already been paired or disconnected.
  while (waiting.length) {
    const otherId = waiting.shift();
    const other = io.sockets.sockets.get(otherId);
    if (!other || otherId === socket.id || peers.has(otherId)) continue;
    peers.set(socket.id, otherId);
    peers.set(otherId, socket.id);
    socket.emit("matched", { initiator: true, partnerId: otherId });
    other.emit("matched", { initiator: false, partnerId: socket.id });
    return;
  }
  waiting.push(socket.id);
  socket.emit("waiting");
}

io.on("connection", (socket) => {
  socket.on("find-partner", () => {
    if (peers.has(socket.id)) return;
    findPartner(socket);
  });

  socket.on("signal", ({ to, data }) => {
    if (!to || peers.get(socket.id) !== to) return;
    io.to(to).emit("signal", { from: socket.id, data });
  });

  socket.on("next", () => {
    removeFromQueue(socket.id);
    disconnectPair(socket.id, "skipped");
    findPartner(socket);
  });

  socket.on("leave", () => {
    removeFromQueue(socket.id);
    disconnectPair(socket.id, "left");
  });

  socket.on("report", ({ category }) => {
    const partnerId = peers.get(socket.id);
    reports.push({
      reporter: socket.id,
      reported: partnerId || null,
      category: String(category || "other").slice(0, 80),
      at: new Date().toISOString()
    });
    // Production: store securely, notify moderators, preserve minimal evidence
    // according to a clear privacy policy, and rate-limit report abuse.
    disconnectPair(socket.id, "reported");
    socket.emit("report-received");
  });

  socket.on("disconnect", () => {
    removeFromQueue(socket.id);
    disconnectPair(socket.id);
  });
});

server.listen(PORT, () => {
  console.log(`Friendly Hello running on http://localhost:${PORT}`);
});
