# Friendly Hello — anonymous video chat MVP

A mobile-first web app starter for adult-to-adult random video chat. No user account is required. It includes:
- Mobile responsive interface
- Browser camera/microphone permission
- Basic Socket.IO pairing queue
- WebRTC peer-to-peer video/audio signaling
- A short pre-connection **placeholder house ad** timer
- Leave/next/report controls
- Community rules page

## Important: this is a prototype, not a child-safe production service

This MVP is **18+ only**. A checkbox is not real age verification, the report queue is in-memory and not staffed, the ad is a placeholder (not a paid ad network), and a public STUN server alone will not connect all networks. Do not market it as fully family-safe or launch broadly before implementing the safety checklist below.

## Run locally

Requires Node.js 20+:
```bash
npm install
npm start
```
Open `http://localhost:3000`. Camera access generally requires HTTPS outside localhost.

## Deploy

Deploy the Node app to a host that supports persistent WebSocket connections (for example, a suitable Node hosting service). Set `PORT` if required. Use HTTPS. Test on at least two separate devices and networks.

## Before public launch

1. Configure a TURN service for WebRTC reliability and protect its credentials using time-limited credentials.
2. Replace the sample house ad with an approved ad provider. Do not claim that the placeholder earns money. Check the ad provider's policies for video chat and user-generated content; never place ads over camera/video in a way that obscures safety controls.
3. Implement real moderation: staffed reports, report storage, abuse rate limits, blocks, bans, appeals, escalation, and an incident response policy.
4. Add meaningful age gating/verification appropriate to the target audience. This starter is adult-only; do not allow children into anonymous stranger chat.
5. Add automated and human safety systems for sexual content, harassment, threats, and grooming; provide an immediate exit and reliable report flow.
6. Add a privacy policy, terms, contact details, retention/deletion policy, cookie/ad disclosures, and applicable consent notices.
7. Review local laws and Apple/Google policies before distributing apps. If this website is packaged as an app, store review may require additional safety and moderation functionality.
8. Add request limits, origin restrictions, TLS, security headers, dependency updates, monitoring, and protection against denial-of-service.
9. Review privacy implications: video is peer-to-peer in this MVP, but signaling metadata and IP addresses may be exposed to the service and/or peers. A TURN relay can change network exposure; explain this accurately to users.

## Current limitations

- The report list is not persisted or sent to a moderator.
- The ad timer is a local placeholder and produces no revenue.
- No login, user profiles, or persistent block list.
- No genuine face verification; camera permission only means the user allowed camera access.
- Basic random queue only; no topic matching or moderation before matching.
- Uses public STUN only; some calls will fail without TURN.
